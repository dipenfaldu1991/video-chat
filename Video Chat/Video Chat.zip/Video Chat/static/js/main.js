console.log("workuing")


// var labelUsername = document.querySelector("#label-username")
var usernameInput = document.querySelector("#username-input")
var btnJoin = document.querySelector("#btn-join")

var username;

var webSocket;

function webSocketOnMessage(event)
{
    
    
    var parseData = JSON.parse(event.data);
    var message = parseData['message']
    console.log("themessage is ",message)
}
btnJoin.addEventListener("click",function(){
    username = usernameInput.value
    console.log("username",username)
    if(username =="")
    {
        return;
    }
    else
    {
        usernameInput.value = ""
        usernameInput.disabled = true
        usernameInput.style.visibility = 'hidden'

        btnJoin.disabled = true
        btnJoin.style.visibility = 'hidden'

        var labelUsername =document.querySelector("#label-username")
        labelUsername.innerHTML = username

        var loc  = window.location
        var wsstart = 'ws://'

        if(loc.protocol == "https:")
        {
            wsstart = 'wss"//'
        }

        var endPoint = wsstart +loc.host +loc.pathname
        // console.log("loc.host",loc.host)
        // console.log("loc.pathname",loc.pathname)
        console.log("endpoint",endPoint)
        
        webSocket = new WebSocket(endPoint);
        
        webSocket.addEventListener('open',function(){
            console.log("connection opened")

            var jsonStr = JSON.stringify({
                "message":"test message1212"
            })

            // webSocket.onopen = function() {
            //     webSocket.send('Hello server')
            //     webSocket.close()
            // }
            webSocket.send(jsonStr)
            console.log("donewa")
        })
        webSocket.addEventListener('message',webSocketOnMessage)
        webSocket.addEventListener('close',function(){
            console.log("connection closed")
        })
        webSocket.addEventListener('error',function(){
            console.log("error occured")
        })
    }
})


var localStream = new MediaStream();

const constraints = {
    'video':true,
    'audio':true
}

const localVideo = document.querySelector("#local-video")
var userMedia = navigator.mediaDevices.getUserMedia(constraints).then(stream =>{
    localStream = stream
    localVideo.src = localStream
    localVideo.muted=true

}).catch(error =>{
    console.log("error",error)
})